let plants = [];
let zombies = [];
let bullets = [];
let spawnTimer = 0;
let gameOver = false;

function setup() {
  createCanvas(800, 400);
  textFont('Georgia');

  // Linha com várias plantas
  for (let y = 80; y <= 320; y += 80) {
    plants.push(new Plant(100, y - 20));
  }
}

function draw() {
  background(100, 200, 100); // grama
  drawGrassLines();

  if (gameOver) {
    drawGameOver();
    return;
  }

  // Atualiza e desenha plantas
  for (let plant of plants) {
    plant.update();
    plant.show();
  }

  // Atualiza e desenha balas
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].update();
    bullets[i].show();

    if (bullets[i].x > width) {
      bullets.splice(i, 1);
    }
  }

  // Gera zumbis
  spawnTimer++;
  if (spawnTimer > 100) {
    let rowY = random([60, 140, 220, 300]);
    zombies.push(new Zombie(width, rowY));
    spawnTimer = 0;
  }

  // Atualiza e desenha zumbis
  for (let i = zombies.length - 1; i >= 0; i--) {
    let zombie = zombies[i];
    zombie.update();
    zombie.show();

    // Verifica colisão com balas
    for (let j = bullets.length - 1; j >= 0; j--) {
      if (dist(zombie.x + 15, zombie.y + 25, bullets[j].x, bullets[j].y + 10) < 20) {
        zombie.health -= 1;
        bullets.splice(j, 1);
        break;
      }
    }

    if (zombie.health <= 0) {
      zombies.splice(i, 1);
    } else if (zombie.x < 0) {
      gameOver = true;
    }
  }
}

// Desenha linhas de grama
function drawGrassLines() {
  stroke(80, 180, 80);
  for (let y = 0; y < height; y += 80) {
    line(0, y, width, y);
  }
  noStroke();
}

// Tela de Game Over
function drawGameOver() {
  textSize(50);
  fill(255, 0, 0);
  textAlign(CENTER, CENTER);
  text('Game Over!', width / 2, height / 2);
  noLoop();
}

// --- CLASSES ---

class Plant {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.timer = 0;
  }

  update() {
    this.timer++;
    if (this.timer > 60) {
      bullets.push(new Bullet(this.x + 20, this.y));
      this.timer = 0;
    }
  }

  show() {
    noStroke();
    fill(30, 200, 30);
    ellipse(this.x + 10, this.y + 10, 30, 30); // corpo
    fill(0, 150, 0);
    ellipse(this.x + 5, this.y + 5, 10, 10);   // olho esquerdo
    ellipse(this.x + 15, this.y + 5, 10, 10);  // olho direito
  }
}

class Bullet {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = 5;
  }

  update() {
    this.x += this.speed;
  }

  show() {
    fill(255, 255, 0);
    stroke(200, 200, 0);
    strokeWeight(2);
    ellipse(this.x, this.y + 10, 10, 10);
    noStroke();
  }
}

class Zombie {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = 1;
    this.health = 3;
  }

  update() {
    this.x -= this.speed;
  }

  show() {
    fill(100, 70, 30);
    rect(this.x, this.y, 30, 50, 8); // corpo

    fill(0);
    ellipse(this.x + 10, this.y + 10, 6, 6); // olho 1
    ellipse(this.x + 20, this.y + 10, 6, 6); // olho 2

    fill(150, 0, 0);
    rect(this.x + 5, this.y + 35, 20, 5); // boca
  }
}
